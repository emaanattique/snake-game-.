# Snake Game — Linux Terminal

A classic Snake game built in C++ that runs in the Linux terminal (WSL on Windows).

---

## Description

This is a terminal-based Snake game where the player controls a snake that moves around a grid. The snake grows longer every time it eats food. The game ends when the snake hits a wall or runs into itself. The goal is to eat as much food as possible and get the highest score.

---

## How It Works

- The game runs inside the Linux terminal using text characters to draw the map
- The snake is drawn using `O` for body and arrow characters (`>`, `<`, `v`, `^`) for the head
- Food is shown as `*`
- The map is redrawn every tick by moving the cursor back to the top of the screen instead of clearing it — this avoids flickering
- The terminal is put into raw mode so keypresses are read instantly without needing to press Enter

---

## Why Linux Terminal

The game uses Linux-only system libraries:

- **termios.h** — puts the terminal into raw mode so keys like `W`, `A`, `S`, `D` are read instantly, one character at a time, without waiting for Enter
- **fcntl.h** — switches the input between blocking mode (for menus) and non-blocking mode (for the game loop), so the snake keeps moving even when no key is pressed
- **unistd.h** — provides `usleep()` to control the game speed

These libraries are only available on Linux/Unix systems. This is why the game must run in a Linux terminal. On Windows, WSL (Windows Subsystem for Linux) is used to get a Linux environment.

---

## Features

- Smooth in-place rendering (no screen flicker)
- Colored output — green snake, red food, yellow head, green borders
- 3 difficulty levels — Easy, Medium, Hard (controls snake speed)
- Pause and resume with `P`
- High score tracking across multiple rounds
- Restart or Quit after game over

---

## Project Structure

The project is split into multiple files, each handling one responsibility:

| File | What it does |
|---|---|
| `macros.cpp` | All constants and settings (map size, speed, characters) |
| `globals.cpp` | All shared game variables (snake arrays, score, flags) |
| `input.cpp` | Keyboard input, terminal raw mode, blocking/non-blocking switch |
| `snake.cpp` | Snake movement, direction logic, collision detection |
| `snake_map.cpp` | Map drawing, food placement, all menus and screens |
| `main.cpp` | Game loop, ties everything together |

---

## How It Was Built

### Step 1 — Basic structure
The game started as a single C++ file with all logic in one place. It was then split into separate files to keep each part clean and easy to understand.

### Step 2 — No OOP
The project intentionally uses only basic C++ constructs — functions, arrays, loops, and global variables. No classes or object-oriented concepts are used. This keeps the code simple and easy to follow.

### Step 3 — Terminal input
The biggest challenge was reading keyboard input without pressing Enter. This was solved using `termios.h` to disable line buffering. Non-blocking input using `fcntl.h` allows the game loop to keep running even when no key is pressed.

### Step 4 — Screen rendering
Instead of clearing the whole screen every frame (which causes flickering), the cursor is moved back to the top using the ANSI escape code `\033[H`. The map is then redrawn in place, giving smooth animation.

### Step 5 — Features added
- Difficulty levels were added by changing the `usleep()` delay — slower delay means easier, faster delay means harder
- Pause was added with a simple `bool paused` flag that stops movement when true
- High score was added with a single `int high_score` variable that persists between rounds
- Colors were added using ANSI escape codes like `\033[32m` for green

---

## Controls

| Key | Action |
|---|---|
| `W` | Move Up |
| `S` | Move Down |
| `A` | Move Left |
| `D` | Move Right |
| `P` | Pause / Resume |
| `Ctrl+C` | Quit |

---

## How to Build and Run

**Requirements:** GCC compiler with C++11 support, Linux or WSL

**Build:**
```
make
```

**Run:**
```
./snake
```

---

## Difficulty Levels

| Level | Speed |
|---|---|
| Easy | Slow — good for beginners |
| Medium | Normal speed |
| Hard | Fast — for experienced players |

---
