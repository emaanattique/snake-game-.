#pragma once

// Map size
const int  MAP_WIDTH            = 20;
const int  MAP_HEIGHT           = 20;

// Characters
const char MAP_CHAR             = '.';
const char SNAKE_CHAR           = 'O';
const char SNAKE_HEAD_WEST      = '>';
const char SNAKE_HEAD_NORTH     = 'v';
const char SNAKE_HEAD_EAST      = '<';
const char SNAKE_HEAD_SOUTH     = '^';
const char SNAKE_FOOD_CHAR      = '*';

// Game settings
const int  INITIAL_SNAKE_LENGTH = 3;
const int  MAX_SNAKE_LENGTH     = MAP_WIDTH * MAP_HEIGHT;

// Difficulty levels (pause length in microseconds — smaller = faster)
const int SPEED_EASY   = 300000; // slow
const int SPEED_MEDIUM = 180000; // normal
const int SPEED_HARD   = 80000;  // fast

// Direction
enum Direction { Error = -1, West = 0, North = 1, East = 2, South = 3 };
