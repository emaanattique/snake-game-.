#include "input.cpp"
#include "snake.cpp"
#include "snake_map.cpp"
#include <csignal>
#include <unistd.h>
#include <iostream>

using namespace std;

void on_exit(int)
{
    set_nonblocking(false);
    input_enter_on();
    cout << "\033[?25h\n" << CLR_RESET << "Game stopped.\n";
    exit(0);
}

void reset_game()
{
    is_dead        = false;
    food_eaten     = false;
    paused         = false;
    current_dir    = East;
    next_dir       = East;
    snake_length   = INITIAL_SNAKE_LENGTH;
    snake_head_row = 0;
    snake_head_col = 0;

    init_map();
    init_snake();
    place_food();
}

int main()
{
    signal(SIGINT,  on_exit);
    signal(SIGTERM, on_exit);

    input_enter_off();

    while (true)
    {
        // Difficulty menu
        set_nonblocking(false);
        pause_length = show_difficulty_menu();

        reset_game();

        cout << "\033[2J\033[H\033[?25l";
        cout.flush();

        set_nonblocking(true);

        // Game loop
        while (true)
        {
            check_game_input();

            // Handle pause
            if (paused)
            {
                set_nonblocking(false);
                show_pause_screen();

                // Wait for P to unpause
                while (true)
                {
                    char key = read_menu_key();
                    if (key == 'p' || key == 'P')
                    {
                        paused = false;
                        break;
                    }
                }

                // Redraw game and go back to non-blocking
                cout << "\033[2J\033[H";
                set_nonblocking(true);
                draw_and_print();
                continue;
            }

            update_direction();
            move_snake();

            if (is_dead)
            {
                set_nonblocking(false);
                cout << "\033[?25h";

                bool restart = show_game_over_screen();
                if (!restart)
                {
                    input_enter_on();
                    cout << "\033[2J\033[H";
                    cout << CLR_GREEN << CLR_BOLD << "  Thanks for playing!\n" << CLR_RESET;
                    return 0;
                }
                break;
            }

            if (food_eaten)
                place_food();

            draw_and_print();
            usleep(pause_length);
        }
    }

    return 0;
}
