#pragma once

#include "macros.cpp"

// Snake position arrays
int snake_row[MAX_SNAKE_LENGTH];
int snake_col[MAX_SNAKE_LENGTH];
int snake_length   = INITIAL_SNAKE_LENGTH;
int snake_head_row = 0;
int snake_head_col = 0;
bool is_dead       = false;
bool food_eaten    = false;

// Food position
int food_row = 0;
int food_col = 0;

// Direction
Direction current_dir = East;
Direction next_dir    = East;

// Map arrays
char map_grid[MAP_HEIGHT][MAP_WIDTH];
int  world[MAP_HEIGHT][MAP_WIDTH];

// Current difficulty speed
int pause_length = SPEED_MEDIUM;

// High score — persists across restarts
int high_score = 0;

// Pause flag
bool paused = false;
