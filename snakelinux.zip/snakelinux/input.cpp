#pragma once

#include "globals.cpp"
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <iostream>

using namespace std;

static struct termios t_orig;

void input_enter_off()
{
    struct termios t;
    tcgetattr(STDIN_FILENO, &t_orig);
    t = t_orig;
    t.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &t);
}

void input_enter_on()
{
    tcsetattr(STDIN_FILENO, TCSANOW, &t_orig);
}

void set_nonblocking(bool on)
{
    int flags = fcntl(STDIN_FILENO, F_GETFL, 0);
    if (on)
        fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);
    else
        fcntl(STDIN_FILENO, F_SETFL, flags & ~O_NONBLOCK);
}

void check_game_input()
{
    char key;
    int result = read(STDIN_FILENO, &key, 1);
    if (result <= 0) return;

    if (key == 'w' || key == 'W') next_dir = North;
    if (key == 's' || key == 'S') next_dir = South;
    if (key == 'a' || key == 'A') next_dir = West;
    if (key == 'd' || key == 'D') next_dir = East;
    if (key == 'p' || key == 'P') paused = !paused;  // toggle pause
}

char read_menu_key()
{
    set_nonblocking(false);
    char key;
    read(STDIN_FILENO, &key, 1);
    return key;
}
