#pragma once

#include "globals.cpp"

void update_direction()
{
    // No mutex needed anymore - no thread
    if (next_dir == West  && current_dir != East)  current_dir = West;
    if (next_dir == North && current_dir != South) current_dir = North;
    if (next_dir == East  && current_dir != West)  current_dir = East;
    if (next_dir == South && current_dir != North) current_dir = South;
}

void move_snake()
{
    int new_row = snake_head_row;
    int new_col = snake_head_col;

    if (current_dir == West)  new_col--;
    if (current_dir == North) new_row--;
    if (current_dir == East)  new_col++;
    if (current_dir == South) new_row++;

    // Check wall collision
    if (new_row < 0 || new_row >= MAP_HEIGHT ||
        new_col < 0 || new_col >= MAP_WIDTH)
    {
        is_dead = true;
        return;
    }

    // Add new head
    snake_row[snake_length] = new_row;
    snake_col[snake_length] = new_col;
    snake_length++;

    snake_head_row = new_row;
    snake_head_col = new_col;

    // Check food
    food_eaten = (new_row == food_row && new_col == food_col);

    if (!food_eaten)
    {
        // Remove tail
        world[snake_row[0]][snake_col[0]]--;
        for (int i = 0; i < snake_length - 1; i++)
        {
            snake_row[i] = snake_row[i + 1];
            snake_col[i] = snake_col[i + 1];
        }
        snake_length--;
    }

    // Check self collision
    world[new_row][new_col]++;
    if (world[new_row][new_col] > 1)
        is_dead = true;
}

void init_snake()
{
    int start_row = MAP_HEIGHT / 2;
    int start_col = MAP_WIDTH  / 2 - INITIAL_SNAKE_LENGTH / 2;

    for (int i = 0; i < INITIAL_SNAKE_LENGTH; i++)
    {
        snake_row[i] = start_row;
        snake_col[i] = start_col + i;
        world[start_row][start_col + i] = 1;
    }

    snake_head_row = snake_row[INITIAL_SNAKE_LENGTH - 1];
    snake_head_col = snake_col[INITIAL_SNAKE_LENGTH - 1];
    snake_length   = INITIAL_SNAKE_LENGTH;
}
