#pragma once

#include "globals.cpp"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>

using namespace std;

// ANSI color codes
const string CLR_RESET  = "\033[0m";
const string CLR_GREEN  = "\033[32m";
const string CLR_YELLOW = "\033[33m";
const string CLR_RED    = "\033[31m";
const string CLR_CYAN   = "\033[36m";
const string CLR_WHITE  = "\033[37m";
const string CLR_BOLD   = "\033[1m";

void place_food()
{
    int r, c;
    do {
        r = rand() % MAP_HEIGHT;
        c = rand() % MAP_WIDTH;
    } while (world[r][c] != 0);
    food_row = r;
    food_col = c;
}

void clear_map()
{
    for (int i = 0; i < MAP_HEIGHT; i++)
        for (int j = 0; j < MAP_WIDTH; j++)
            map_grid[i][j] = MAP_CHAR;
}

void draw_and_print()
{
    clear_map();

    for (int i = 0; i < snake_length; i++)
        map_grid[snake_row[i]][snake_col[i]] = SNAKE_CHAR;

    char head_char = SNAKE_CHAR;
    if (current_dir == West)  head_char = SNAKE_HEAD_WEST;
    if (current_dir == North) head_char = SNAKE_HEAD_NORTH;
    if (current_dir == East)  head_char = SNAKE_HEAD_EAST;
    if (current_dir == South) head_char = SNAKE_HEAD_SOUTH;
    map_grid[snake_head_row][snake_head_col] = head_char;

    map_grid[food_row][food_col] = SNAKE_FOOD_CHAR;

    cout << "\033[H";

    // ── Top border ──────────────────────────────────
    cout << CLR_GREEN << "+" ;
    for (int j = 0; j < MAP_WIDTH; j++) cout << "--";
    cout << "+" << CLR_RESET << "\n";

    // ── Rows ────────────────────────────────────────
    for (int i = 0; i < MAP_HEIGHT; i++)
    {
        cout << CLR_GREEN << "|" << CLR_RESET;
        for (int j = 0; j < MAP_WIDTH; j++)
        {
            char c = map_grid[i][j];
            if (c == SNAKE_FOOD_CHAR)
                cout << CLR_RED << c << " " << CLR_RESET;
            else if (c == SNAKE_CHAR)
                cout << CLR_GREEN << c << " " << CLR_RESET;
            else if (c == SNAKE_HEAD_WEST  || c == SNAKE_HEAD_NORTH ||
                     c == SNAKE_HEAD_EAST  || c == SNAKE_HEAD_SOUTH)
                cout << CLR_BOLD << CLR_YELLOW << c << " " << CLR_RESET;
            else
                cout << CLR_WHITE << c << " " << CLR_RESET;
        }
        cout << CLR_GREEN << "|" << CLR_RESET << "\n";
    }

    // ── Bottom border ────────────────────────────────
    cout << CLR_GREEN << "+";
    for (int j = 0; j < MAP_WIDTH; j++) cout << "--";
    cout << "+" << CLR_RESET << "\n";

    // ── Info bar ─────────────────────────────────────
    cout << CLR_CYAN << " Score: " << CLR_BOLD << snake_length << CLR_RESET;
    cout << CLR_CYAN << "   Best: "  << CLR_BOLD << high_score  << CLR_RESET;
    if (paused)
        cout << CLR_RED << CLR_BOLD << "   [ PAUSED ]" << CLR_RESET;
    cout << "\n";
    cout << CLR_WHITE << " W/A/S/D: move   P: pause   Ctrl+C: quit" << CLR_RESET << "\n";

    cout.flush();
}

void init_map()
{
    srand(time(NULL));
    for (int i = 0; i < MAP_HEIGHT; i++)
        for (int j = 0; j < MAP_WIDTH; j++)
            world[i][j] = 0;
}

int show_difficulty_menu()
{
    cout << "\033[2J\033[H";
    cout << CLR_GREEN << CLR_BOLD;
    cout << "  +====================+\n";
    cout << "  |    SNAKE  GAME     |\n";
    cout << "  +====================+\n";
    cout << CLR_RESET << "\n";
    cout << CLR_CYAN << "  Select difficulty:\n\n" << CLR_RESET;
    cout << CLR_GREEN  << "    1 - Easy\n"   << CLR_RESET;
    cout << CLR_YELLOW << "    2 - Medium\n" << CLR_RESET;
    cout << CLR_RED    << "    3 - Hard\n"   << CLR_RESET;
    cout << "\n  Press 1, 2 or 3: ";
    cout.flush();

    char key;
    while (true)
    {
        key = read_menu_key();
        if (key == '1') return SPEED_EASY;
        if (key == '2') return SPEED_MEDIUM;
        if (key == '3') return SPEED_HARD;
    }
}

bool show_game_over_screen()
{
    // Update high score
    if (snake_length > high_score)
        high_score = snake_length;

    cout << "\033[2J\033[H";
    cout << CLR_RED << CLR_BOLD;
    cout << "  +====================+\n";
    cout << "  |     GAME  OVER     |\n";
    cout << "  +====================+\n";
    cout << CLR_RESET << "\n";
    cout << CLR_CYAN  << "  Score:      " << CLR_BOLD << snake_length << CLR_RESET << "\n";
    cout << CLR_YELLOW << "  High Score: " << CLR_BOLD << high_score  << CLR_RESET << "\n\n";
    cout << CLR_GREEN  << "    R - Restart\n" << CLR_RESET;
    cout << CLR_RED    << "    Q - Quit\n"    << CLR_RESET;
    cout << "\n  Press R or Q: ";
    cout.flush();

    char key;
    while (true)
    {
        key = read_menu_key();
        if (key == 'r' || key == 'R') return true;
        if (key == 'q' || key == 'Q') return false;
    }
}

void show_pause_screen()
{
    cout << "\033[2J\033[H";
    cout << CLR_YELLOW << CLR_BOLD;
    cout << "  +====================+\n";
    cout << "  |      PAUSED        |\n";
    cout << "  +====================+\n";
    cout << CLR_RESET << "\n";
    cout << "  Press P to continue...\n";
    cout.flush();
}
